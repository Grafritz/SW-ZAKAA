"use strict";
var $ = jQuery;
jQuery(document).ready(function() {   
   jQuery("#main_slider").revolution({
      sliderType:"standard",
      sliderLayout:"auto",
      loops:false,
      delay:10000,
      navigation: {
          arrows: {
            style: "hades",
            enable: true,
            hide_onmobile: false,
            hide_onleave: false,
            tmp: '<div class="tp-arr-allwrapper"> <div class="tp-arr-imgholder"></div></div>',
            left: {
                h_align: "left",
                v_align: "center",
                h_offset: 10,
                v_offset: 0
            },
            right: {
                h_align: "right",
                v_align: "center",
                h_offset: 10,
                v_offset: 0
            }
        },
      },

      responsiveLevels:[2540,1280,975,991,767,479],
            gridwidth:[1320,1170,975,750,480,450],
            gridheight:[800,800,650,500,500,500],
            shadow:0,
            spinner:"off",
            autoHeight:"off",
            disableProgressBar:"on",
            hideThumbsOnMobile:"off",
            hideSliderAtLimit:0,
            hideCaptionAtLimit:0,
            hideAllCaptionAtLilmit:0,
            debugMode:false,
            fallbacks: {
              simplifyAll:"off",
              disableFocusListener:false,
            }   
    });   
});
//
$(window).scroll(function(){
  var sticky = $('.menu_fixed.main_menu'),
      scroll = $(window).scrollTop();

  if (scroll >= 190) sticky.addClass('fixed');
  else sticky.removeClass('fixed');
}); 

jQuery(document).ready(function() {
  // Submit form drowdown 
  jQuery(".dropdown-menu li").click(function($){
    $(this).parents(".dropdown").find('.btn-dropdown').html($(this).text() + ' <i class="fa fa-angle-down"></i>');
    $(this).parents(".dropdown").find('.btn-dropdown').val($(this).data('value'));
  });
  $('.switch_btn button').click(function(){
        $('.switch_menu').toggle(300)
      });
  $("#boxed").click(function(){
    $(".layout_changer").addClass("home_boxed");
  });
  $("#full_width").click(function(){
    $(".layout_changer").removeClass("home_boxed");
  });
   $(".bg1").click(function(){
    $(".home_boxed").addClass("bg1");
    $(".home_boxed").removeClass("bg2 bg3 bg4");
  });
    $(".bg2").click(function(){
    $(".home_boxed").addClass("bg2");
    $(".home_boxed").removeClass("bg1 bg3 bg4");
  });
     $(".bg3").click(function(){
    $(".home_boxed").addClass("bg3");
    $(".home_boxed").removeClass("bg2 bg1 bg4");
  });
      $(".bg4").click(function(){
    $(".home_boxed").addClass("bg4");
    $(".home_boxed").removeClass("bg2 bg3 bg1");
  });

       $('.main_menu nav ul li.sub_dropdown').append(function () {
          return '<i class="fa fa-sort-desc"></i>';
        });
        $('.main_menu nav ul li.sub_dropdown .fa').on('click', function () {
          $(this).parent('li').children('ul').slideToggle('0001');
        });

      $("#myonoffswitch").click(function(){
      $(".main_menu").toggleClass("menu_fixed");
      $(".main_menu").removeClass("fixed");
  });
});

$(document).ready(function() {
  $('#mixitup_list').mixItUp(); // mix it up 
});

  $(".fancybox").fancybox();
  $(".fancybox").fancybox({
  helpers : {
    overlay : {
      css : {
        'background' : 'rgba(0,0,0,0.7)'
      }
    }
  }
  });

$(document).ready(function() {
 
  var owl = $("#owl-demo");
 
  owl.owlCarousel({
      items : 2, 
      itemsDesktop : [992,2],
      itemsDesktopSmall : [768,1], 
      itemsTablet: [450,1], 
      itemsMobile : false,// itemsMobile disabled - inherit from itemsTablet option
      pagination : false,
      autoPlay:4000
  });
 
  // Custom Navigation Events
  $(".next").click(function(){
    owl.trigger('owl.next');
  })
  $(".prev").click(function(){
    owl.trigger('owl.prev');
  })
});
$(document).ready(function() {
 
  var owl = $("#owl-demo2");
 
  owl.owlCarousel({
      items : 1, 
      itemsDesktop : [992,1],
      itemsDesktopSmall : [768,1], 
      itemsTablet: [450,1], 
      itemsMobile : false,// itemsMobile disabled - inherit from itemsTablet option
      pagination : false,
      autoPlay:5000
  });
 
  // Custom Navigation Events
  $(".next").click(function(){
    owl.trigger('owl.next');
  })
  $(".prev").click(function(){
    owl.trigger('owl.prev');
  })
});


$(document).ready(function() {
 
    if ($('.price-ranger').length) {
      $( '.price-ranger #slider-range' ).slider({
        range: true,
        min: 0,
        max: 1200,
        values: [ 99, 1035 ],
        slide: function( event, ui ) {
          $( '.price-ranger .ranger-min-max-block .min' ).val( '$' + ui.values[ 0 ] );
          $( '.price-ranger .ranger-min-max-block .max' ).val( '$' + ui.values[ 1 ] );
        }
      });
        $( '.price-ranger .ranger-min-max-block .min' ).val( '$' + $( '.price-ranger #slider-range' ).slider( 'values', 0 ) );
      $( '.price-ranger .ranger-min-max-block .max' ).val( '$' + $( '.price-ranger #slider-range' ).slider( 'values', 1 ) );        
    };
 
});

$(document).ready(function() {

  $('.accordion > .panel').on('show.bs.collapse', function (e) {
        var heading = $(this).find('.panel-heading');
        heading.addClass("active-panel");
        
  });
  
  $('.accordion > .panel').on('hidden.bs.collapse', function (e) {
      var heading = $(this).find('.panel-heading');
        heading.removeClass("active-panel");
        //setProgressBar(heading.get(0).id);
  });

});

function counterUp () {
  if ($('.counter').length) {
    $('.counter').counterUp({
        delay: 10,
        time: 1300
    });    
  };
}
$(document).ready(function() {
  counterUp();
  $('#accordion_two > .panel').on('show.bs.collapse', function (e) {
        var heading = $(this).find('.panel-heading');
        heading.addClass("active-panel");
        
  });
  
  $('#accordion_two > .panel').on('hidden.bs.collapse', function (e) {
      var heading = $(this).find('.panel-heading');
        heading.removeClass("active-panel");
        //setProgressBar(heading.get(0).id);
  });

});