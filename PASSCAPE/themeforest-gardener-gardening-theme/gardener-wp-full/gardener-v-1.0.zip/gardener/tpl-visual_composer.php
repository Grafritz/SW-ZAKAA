<?php /* Template Name: VC Page */
	get_header() ;
	$meta = _WSH()->get_meta('_bunch_header_settings');
	$bg = gardener_set($meta, 'header_img');
	$title = gardener_set($meta, 'header_title');
	$link =  gardener_set($meta, 'page_link');
?>
<?php if(gardener_set($meta, 'breadcrumb')):?>
<!-- ============================= Inner Banner ========================== -->
<section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
            </div>
        </div>
    </div>
</section> <!-- /inner_banner -->
<!-- ============================= /Inner Banner ========================== -->


<!-- ============================ BreadCrumb ============================= -->
<div class="breadcrumb">
    <div class="container">
        <?php echo gardener_get_the_breadcrumb(); ?>
    </div>
</div> <!-- /breadcrumb -->
<!-- ============================ /BreadCrumb ============================= -->

<?php endif;?>
<?php while( have_posts() ): the_post(); ?>
    <?php the_content(); ?>
<?php endwhile;  ?>
<?php get_footer() ; ?>