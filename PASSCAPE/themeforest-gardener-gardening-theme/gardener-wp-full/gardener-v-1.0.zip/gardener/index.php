<?php bunch_global_variable(); 
	$options = _WSH()->option();
	get_header(); 
	if( $wp_query->is_posts_page ) {
		$meta = _WSH()->get_meta('_bunch_layout_settings', get_queried_object()->ID);
		$meta1 = _WSH()->get_meta('_bunch_header_settings', get_queried_object()->ID);
		if(gardener_set($_GET, 'layout_style')) $layout = gardener_set($_GET, 'layout_style'); else
		$layout = gardener_set( $meta, 'layout', 'right' );
		$sidebar = gardener_set( $meta, 'sidebar', 'default-sidebar' );
		$view = gardener_set( $meta, 'view', 'grid' );
		$bg = gardener_set($meta1, 'header_img');
		$title = gardener_set($meta1, 'header_title');
		$link =  gardener_set($meta1, 'page_link');
	} else {
		$settings  = _WSH()->option(); 
		if(gardener_set($_GET, 'layout_style')) $layout = gardener_set($_GET, 'layout_style'); else
		$layout = gardener_set( $settings, 'archive_page_layout', 'right' );
		$sidebar = gardener_set( $settings, 'archive_page_sidebar', 'default-sidebar' );
		$view = gardener_set( $settings, 'archive_page_view', 'list' );
		$bg = gardener_set($settings, 'archive_page_header_img');
		$title = gardener_set($settings, 'archive_page_header_title');
		$link = gardener_set($settings, 'archive_page_link');
	}
	$layout = gardener_set( $_GET, 'layout' ) ? gardener_set( $_GET, 'layout' ) : $layout;
	$view = gardener_set( $_GET, 'view' ) ? gardener_set( $_GET, 'view' ) : $view;
	$sidebar = ( $sidebar ) ? $sidebar : 'default-sidebar';
	_WSH()->page_settings = array('layout'=>'right', 'sidebar'=>$sidebar);
	$classes = ( !$layout || $layout == 'full' || gardener_set($_GET, 'layout_style')=='full' ) ? ' col-lg-12 col-md-12 col-sm-12 col-xs-12 ' : ' col-lg-9 col-md-12 col-sm-12 col-xs-12 ' ;
	?>
	<!-- ============================= Inner Banner ========================== -->
    <section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                    <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
                </div>
            </div>
        </div>
    </section> <!-- /inner_banner -->
    <!-- ============================= /Inner Banner ========================== -->
    
    <!-- ============================ BreadCrumb ============================= -->
    <div class="breadcrumb">
        <div class="container">
            <?php echo gardener_get_the_breadcrumb(); ?>
        </div>
    </div> <!-- /breadcrumb -->
    <!-- ============================ /BreadCrumb ============================= -->
    
    <section class="blog_fullwidth container news">
        <div class="row">
            <!-- sidebar area -->
            <?php if( $layout == 'left' ): ?>
                <?php if ( is_active_sidebar( $sidebar ) ) { ?>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                        <?php dynamic_sidebar( $sidebar ); ?>
                    </div>
                <?php } ?>
            <?php endif; ?>
            <!-- sidebar area -->
            
            <div class="<?php echo esc_attr($classes);?> single_blog_fullwidth">
                <?php while( have_posts() ): the_post();?>
                    <!-- Post -->
                    <div id="post-<?php the_ID(); ?>" <?php post_class();?>>
                        <?php get_template_part( 'blog' ); ?>
                    </div><!-- End Post -->
                <?php endwhile;?> 
                    <!-- Pagination -->
                <div style="text-align:center;">
                    <?php gardener_the_pagination(); ?>
                </div>
            </div>
            
            <!-- sidebar area -->
            <?php if( $layout == 'right' ): ?>
                <?php if ( is_active_sidebar( $sidebar ) ) { ?>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                        <?php dynamic_sidebar( $sidebar ); ?>
                    </div>
                <?php } ?>
            <?php endif; ?>
            <!-- sidebar area -->
    
        </div> <!-- /row -->
    
    </section> <!-- /blog_fullwidth -->
    
    <!-- ====================== /Blog - Fullwidth With Sidebar ================== -->
<?php get_footer(); ?>