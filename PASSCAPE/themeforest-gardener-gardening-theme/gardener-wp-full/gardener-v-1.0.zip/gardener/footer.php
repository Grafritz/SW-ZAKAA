<?php $options = get_option(GARDENER_NAME.'_theme_options');?>
	
<!-- ============================== Footer ===================== -->
<?php if(!(gardener_set($options, 'hide_whole_footer'))):?>
<footer>
    <div class="container">
        <?php if(!(gardener_set($options, 'hide_upper_footer'))):?>
        <div class="main_footer">
            <?php if ( is_active_sidebar( 'footer-sidebar' ) ) { ?>
                <div class="row clearfix">
                    <?php dynamic_sidebar( 'footer-sidebar' ); ?>
                </div>
            <?php } ?>
        </div> <!-- /main_footer -->
        <?php endif;?>
        
        <?php if(!(gardener_set($options, 'hide_bottom_footer'))):?>
        <div class="bottom_footer">
            <div class="row">
                <div class="col-lg-5 col-md-6 col-sm-8 col-xs-12">
                    <p><?php echo gardener_set($options, 'copy_right');?></p>
                </div>
                <?php if($socials = gardener_set(gardener_set($options, 'social_media'), 'social_media')): //gardener_printr($socials);?>
                    <div class="col-lg-6 col-md-5 col-sm-4 col-xs-12">
                        <div class="social_icon_footer">
                            <ul>
                            	<?php foreach($socials as $key => $value):
									if(gardener_set($value, 'tocopy')) continue;
								?>
                                
                                	<li class="transition3s border_round"><a href="<?php echo esc_url(gardener_set($value, 'social_link'));?>"><i class="fa <?php echo gardener_set($value, 'social_icon');?> border_round"></i></a></li>
                                	
								<?php endforeach;?>
                            </ul>
                        </div><!--  /social_icon_footer -->
                    </div>
                <?php endif;?>
                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                    <a href="#top" class="back_top"><i class="fa fa-chevron-up"></i></a>
                </div>
            </div>
        </div> <!-- /bottom_footer -->
        <?php endif;?>
    </div> <!-- /container -->
</footer>
<?php endif;?>
<!-- ============================== /Footer ===================== -->
</div>
<?php wp_footer(); ?>
</body>
</html>