<?php $options = _WSH()->option();
	get_header(); 
	$settings  = gardener_set(gardener_set(get_post_meta(get_the_ID(), 'bunch_page_meta', true) , 'bunch_page_options') , 0);
	$meta1 = _WSH()->get_meta('_bunch_header_settings');
	$meta2 = _WSH()->get_meta();
	
	$bg = gardener_set($meta1, 'header_img');
	$title = gardener_set($meta1, 'header_title');
	$link =  gardener_set($meta1, 'page_link');
?>

<!-- ============================= Inner Banner ========================== -->
<section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
            </div>
        </div>
    </div>
</section> <!-- /inner_banner -->
<!-- ============================= /Inner Banner ========================== -->

<!-- ============================ BreadCrumb ============================= -->
<div class="breadcrumb">
    <div class="container">
        <?php echo gardener_get_the_breadcrumb(); ?>
    </div>
</div> <!-- /breadcrumb -->
<!-- ============================ /BreadCrumb ============================= -->

<!-- ====================== Blog - Fullwidth With Sidebar ================== -->
<?php while( have_posts() ): the_post(); 
                $post_meta = _WSH()->get_meta();
            ?>
<div class="full_width_details_text container">
	<div class="img_holder">
			<?php if(gardener_set($post_meta, 'before_img')):?>
			<div class="img_left flt_left">
				<img src="<?php echo esc_url(gardener_set($post_meta, 'before_img'));?>" alt="image" class="img-responsive">
				<h5><?php esc_html_e('Before', 'gardener');?></h5>
			</div>
			<?php endif;?>
			<?php if(gardener_set($post_meta, 'after_img')):?>
			<div class="img_right flt_right">
				<img src="<?php echo esc_url(gardener_set($post_meta, 'after_img'));?>" alt="image" class="img-responsive">
				<h5><?php esc_html_e('After', 'gardener');?></h5>
			</div>
			<?php endif;?>
			<div class="clear_fix"></div>
		</div>
		<?php the_content();?>
	</div>
	<!-- ============================ Testimonial =============================== -->
	
	<section class="details_page_testimonial container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 client_slider">
				<div class="img_holder"> <!-- image holder -->
					<?php if($slides = gardener_set($post_meta, 'bunch_slider_image')):?>
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
					  <!-- Indicators -->
					  <ol class="carousel-indicators">
					    <?php foreach($slides as $key => $value):?>
							<li data-target="#myCarousel" data-slide-to="<?php echo $key;?>" <?php if($key == 0) echo 'class="active"';?>></li>
						<?php endforeach;?>
					  </ol>
					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
					     <?php foreach($slides as $key => $value):?>
						<div class="item <?php if($key == 0) echo ' active';?>">
					      <img src="<?php echo esc_url(gardener_set($value, 'slider_img'));?>" alt="Chania">
					    </div>
						<?php endforeach;?>
					  </div>
					</div>
					 <?php endif;?>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 testimonial">
			<?php if($clients_wording = gardener_set($post_meta, 'bunch_client')):?>
				<div class="owl_slider row">
					<div id="owl-demo2">
					<?php foreach($clients_wording as $key => $value):?>
						<div class="item">
							<div class="client_speach">
								<h5><?php echo gardener_set($value, 'client_title');?></h5>
								<p><?php echo gardener_set($value, 'client_description');?></p>
								<div class="client_name">
									<h5><?php echo gardener_set($value, 'client_name');?></h5>
									<ul>
										<?php
											$ratting = gardener_set($value, 'client_testimonial_rating');
											for ($x = 1; $x <= 5; $x++) {
											if($x <= $ratting) echo '<li><a href="#"><i class="fa fa-star"></i></a></li>'; else echo '<li><a href="#"><i class="fa fa-star empty"></i></a></li>'; 
										}
										?>
									</ul>
								</div> <!-- /client_name -->
								<?php if(gardener_set($value, 'client_sign_img')):?>
									<img src="<?php echo esc_url(gardener_set($value, 'client_sign_img'));?>" alt="sign">
								<?php endif;?>
							</div> <!-- /client_speach -->
						</div>
						<?php endforeach;?>
					</div> <!-- end #owl-demo -->
				</div> <!-- End owl-slider -->
				<?php endif;?>
			</div>
		</div>
	</section>
	<?php endwhile;?>

<?php get_footer(); ?>