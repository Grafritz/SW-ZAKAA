<div class="single_blog_post">
    <?php if ( has_post_thumbnail() ):?>
    <div class="img_holder">
        <?php the_post_thumbnail('gardener_eleven', array('class' => 'img-responsive'));?>
        <div class="overlay transition3s">
            <div class="icon_position_table">
                <div class="icon_container border_round">
                    <a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="border_round"><i class="fa fa-chain"></i></a>
                </div>
            </div>
        </div>
    </div> <!-- /img_holder -->
    <?php endif;?>
    <div class="post g_post">
        <h4><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php the_title();?></a></h4>
        <ul class="g_list">
            <li><a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>" class="transition-ease"><span><?php esc_html_e('Date :', 'gardener');?></span><?php echo get_the_date('M d, Y');?></a></li>
            <li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>" class="transition-ease"><span><?php esc_html_e('By :', 'gardener');?></span> <?php the_author();?></a></li>
            <li><a href="<?php echo esc_url(get_permalink(get_the_id()).'#comments');?>" class="transition-ease"><span><?php esc_html_e('Comment :', 'gardener');?></span><?php comments_number( '0 comment', '1 comment', '% comments' ); ?></a></li>
            <li><a><span><?php esc_html_e('Category :', 'gardener');?></span></a><?php the_category(', '); ?></li>
        </ul>
        <?php the_excerpt();?>
        <a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="continue_reading transition-ease"><?php esc_html_e('Continue Reading...', 'gardener');?></a>
    </div> <!-- /post -->
</div>