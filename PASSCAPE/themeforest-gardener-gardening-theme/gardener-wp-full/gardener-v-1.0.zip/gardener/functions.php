<?php
add_action('after_setup_theme', 'gardener_bunch_theme_setup');
function gardener_bunch_theme_setup()
{
	global $wp_version;
	if(!defined('GARDENER_VERSION')) define('GARDENER_VERSION', '1.0');
	if( !defined( 'GARDENER_NAME' ) ) define( 'GARDENER_NAME', 'wp_gardener' );
	if( !defined( 'GARDENER_ROOT' ) ) define('GARDENER_ROOT', get_template_directory().'/');
	if( !defined( 'GARDENER_URL' ) ) define('GARDENER_URL', get_template_directory_uri().'/');	
	include_once get_template_directory() . '/includes/loader.php';
	
	
	load_theme_textdomain('gardener', get_template_directory() . '/languages');
	
	//ADD THUMBNAIL SUPPORT
	add_theme_support('post-thumbnails');
	add_theme_support('menus'); //Add menu support
	add_theme_support('automatic-feed-links'); //Enables post and comment RSS feed links to head.
	add_theme_support('widgets'); //Add widgets and sidebar support
	add_theme_support( "title-tag" );
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
	/** Register wp_nav_menus */
	if(function_exists('register_nav_menu'))
	{
		register_nav_menus(
			array(
				/** Register Main Menu location header */
				'main_menu' => esc_html__('Main Menu', 'gardener'),
			)
		);
	}
	if ( ! isset( $content_width ) ) $content_width = 960;
	add_image_size( 'gardener_one', 270, 235, true ); // '270x235 Welcome Services'
	add_image_size( 'gardener_two', 170, 150, true ); // '170x150 Services 2 Col'
	add_image_size( 'gardener_three', 370, 260, true ); // '370x260 Project Gallery'
	add_image_size( 'gardener_four', 370, 220, true ); // '370x220 Blog Page'
	add_image_size( 'gardener_five', 370, 280, true ); // '370x280 Team'
	add_image_size( 'gardener_six', 370, 235, true ); // '370x235 All Services'
	add_image_size( 'gardener_seven', 443, 400, true ); // '443x400 Project V1'
	add_image_size( 'gardener_eight', 1232, 600, true ); // '1232x600 Project Masonery'
	add_image_size( 'gardener_nine', 599, 1230, true ); // '599x1230 Project Masonery'
	add_image_size( 'gardener_ten', 599, 600, true ); // '599x600 Project Masonery'
	add_image_size( 'gardener_eleven', 1170, 520, true ); // '1170x520 Blog Page'
	add_image_size( 'gardener_tweleve', 70, 70, true ); // '70x70 Recent Post'
	
	
	
	
}
function gardener_bunch_widget_init()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_Get_in_Touch' ) )register_widget( 'Bunch_Get_in_Touch' );
	if( class_exists( 'Bunch_Recent_Post_With_Image' ) )register_widget( 'Bunch_Recent_Post_With_Image' );
	if( class_exists( 'Bunch_Contact_us' ) )register_widget( 'Bunch_Contact_us' );
	
	
	
	register_sidebar(array(
	  'name' => esc_html__( 'Default Sidebar', 'gardener' ),
	  'id' => 'default-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'gardener' ),
	  'class'=>'',
	  'before_widget'=>'<div id="%1$s" class="widget sidebar_widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<h5>',
	  'after_title' => '</h5>'
	));
	register_sidebar(array(
	  'name' => esc_html__( 'Footer Sidebar', 'gardener' ),
	  'id' => 'footer-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown in Footer Area.', 'gardener' ),
	  'class'=>'',
	  'before_widget'=>'<div id="%1$s"  class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer_widget footer-widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<h5>',
	  'after_title' => '</h5>'
	));
	
	register_sidebar(array(
	  'name' => esc_html__( 'Blog Listing', 'gardener' ),
	  'id' => 'blog-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'gardener' ),
	  'class'=>'',
	  'before_widget'=>'<div id="%1$s" class="widget sidebar_widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<h5>',
	  'after_title' => '</h5>'
	));
	if( !is_object( _WSH() )  )  return;
	$sidebars = gardener_set(gardener_set( $theme_options, 'dynamic_sidebar' ) , 'dynamic_sidebar' ); 
	foreach( array_filter((array)$sidebars) as $sidebar)
	{
		if(gardener_set($sidebar , 'topcopy')) continue ;
		
		$name = gardener_set( $sidebar, 'sidebar_name' );
		
		if( ! $name ) continue;
		$slug = gardener_bunch_slug( $name ) ;
		
		register_sidebar( array(
			'name' => $name,
			'id' =>  $slug ,
			'before_widget' => '<div id="%1$s" class="side-bar widget sidebar_widget %2$s">',
			'after_widget' => "</div>",
			'before_title' => '<div class="sec-title"><h3 class="skew-lines">',
			'after_title' => '</h3></div>',
		) );		
	}
	
	update_option('wp_registered_sidebars' , $wp_registered_sidebars) ;
}
add_action( 'widgets_init', 'gardener_bunch_widget_init' );
// Update items in cart via AJAX
add_filter('add_to_cart_fragments', 'gardener_bunch_woo_add_to_cart_ajax');
function gardener_bunch_woo_add_to_cart_ajax( $fragments ) {
    
	global $woocommerce;
    ob_start();
	
	get_template_part('includes/modules/wc_cart' );
	
	$fragments['li.wc-header-cart'] = ob_get_clean();
	
    return $fragments;
}
add_filter( 'woocommerce_enqueue_styles', '__return_false' );
function gardener_bunch_animate_it( $atts, $contents = null )
{
	return get_template_part( 'includes/modules/shortcodes/animate_it' );
}
function gardener_load_head_scripts() {
    if ( !is_admin() ) {
	$protocol = is_ssl() ? 'https://' : 'http://';	
    wp_register_script( 'gardener_map_api', ''.$protocol.'maps.google.com/maps/api/js?sensor=true', '', '', false);
	wp_register_script( 'gardener-googlemap', get_template_directory_uri().'/js/gmap.js', '', '', false);
    wp_enqueue_script( 'gardener_map_api' );
	wp_enqueue_script( 'gardener-googlemap' );
    }
    }
    add_action( 'wp_enqueue_scripts', 'gardener_load_head_scripts' );
//global variables
function bunch_global_variable() {
    global $wp_query;
}
/*-------------------------------------------------------------*/

function gardener_enqueue_scripts() {
	$protocol = is_ssl() ? 'https://' : 'http://';
    //styles
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap/bootstrap.css' );
	wp_enqueue_style( 'owl-slider', get_template_directory_uri() . '/css/owl.carousel.css' );
	wp_enqueue_style( 'owl-theme', get_template_directory_uri() . '/css/owl.theme.css' );
	wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/fancy-box/jquery.fancybox.css' );
	wp_enqueue_style( 'fontawesom', get_template_directory_uri() . '/fonts/font-awesome/css/font-awesome.min.css' );
	if(class_exists('woocommerce')) wp_enqueue_style( 'woocommerce', get_template_directory_uri() . '/css/woocommerce.css' );
	wp_enqueue_style( 'gardener_main-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'gardener_responsive', get_template_directory_uri() . '/css/responsive/responsive.css' );
	wp_enqueue_style( 'gardener_custom-style', get_template_directory_uri() . '/css/custom.css' );
	
	//scripts
	wp_enqueue_script( 'bootstrap', get_template_directory_uri().'/js/bootstrap.min.js', array(), false, true );
	wp_enqueue_script( 'mixitup', get_template_directory_uri().'/js/jquery.mixitup.min.js', array(), false, true );
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri().'/js/owl.carousel.min.js', array(), false, true );
	wp_enqueue_script( 'gmap', get_template_directory_uri().'/js/gmap.js', array(), false, true );
	wp_enqueue_script( 'fancybox', get_template_directory_uri().'/js/jquery.fancybox.pack.js', array(), false, true );
	wp_enqueue_script( 'counter', get_template_directory_uri().'/js/jquery.counterup.min.js', array(), false, true );
	wp_enqueue_script( 'cloud-flare', ''.$protocol.'cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js', array(), false, true );
	wp_enqueue_script( 'gardener_main_script', get_template_directory_uri().'/js/main.js', array(), false, true );
	
}
add_action( 'wp_enqueue_scripts', 'gardener_enqueue_scripts' );
add_action( 'wp_enqueue_scripts', 'wps_enqueue_lt_ie9' );
/**
 * Conditionally Enqueue Script for IE browsers less than IE 9
 *
 * @link http://php.net/manual/en/function.version-compare.php
 * @uses wp_check_browser_version()
 */
function wps_enqueue_lt_ie9() {
    global $is_IE;
    // Return early, if not IE
    if ( ! $is_IE ) return;
    // Include the file, if needed
    if ( ! function_exists( 'wp_check_browser_version' ) )
        include_once ABSPATH . 'wp-admin/includes/dashboard.php';
    // IE version conditional enqueue
    $response = wp_check_browser_version();
    if ( 0 > version_compare( intval( $response['version'] ) , 9 ) )
        wp_enqueue_script( 'wp-html5shiv', get_template_directory_uri().'/js/html5shiv.js', array(), 'pre3.6', false );
		wp_enqueue_script( 'wp-respond', get_template_directory_uri().'/js/respond.js', array(), '1.0', false );
}
/*-------------------------------------------------------------*/
function gardener_theme_slug_fonts_url() {
    $fonts_url = '';
 
    /* Translators: If there are characters in your language that are not
    * supported by Lora, translate this to 'off'. Do not translate
    * into your own language.
    */
    $roboto = _x( 'on', 'Roboto font: on or off', 'gardener' );
	$lora = _x( 'on', 'Lora font: on or off', 'gardener' );
	
    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'gardener' );
 
    if ( 'off' !== $roboto || 'off' !== $open_sans || 'off' !== $lora ) {
        $font_families = array();
 
        if ( 'off' !== $roboto ) {
            $font_families[] = 'Roboto:400,300,300italic,400italic,500,500italic,700,700italic,900,900italic';
        }
		
		if ( 'off' !== $lora ) {
            $font_families[] = 'Lora:400,400italic,700,700italic';
        }
		
		if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:400,400italic,600,300italic,300';
        }
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }
 
    return esc_url_raw( $fonts_url );
}
function gardener_theme_slug_scripts_styles() {
    wp_enqueue_style( 'gardener-theme-slug-fonts', gardener_theme_slug_fonts_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'gardener_theme_slug_scripts_styles' );
/*---------------------------------------------------------------------*/
function gardener_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action( 'admin_init', 'gardener_add_editor_styles' );
/**
 * WooCommerce Extra Feature
 * --------------------------
 *
 * Change number of related products on product page
 * Set your own value for 'posts_per_page'
 *
 */ 
function woo_related_products_limit() {
  global $product;
	
	$args['posts_per_page'] = 6;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'jk_related_products_args' );
  function jk_related_products_args( $args ) {
	$args['posts_per_page'] = 3; // 4 related products
	$args['columns'] = 3; // arranged in 2 columns
	return $args;
}