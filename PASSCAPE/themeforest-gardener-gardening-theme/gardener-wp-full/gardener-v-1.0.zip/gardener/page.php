<?php $options = _WSH()->option();
	get_header();
	$settings  = gardener_set(gardener_set(get_post_meta(get_the_ID(), 'bunch_page_meta', true) , 'bunch_page_options') , 0);
	$meta = _WSH()->get_meta('_bunch_layout_settings');
	$meta1 = _WSH()->get_meta('_bunch_header_settings');
	if(gardener_set($_GET, 'layout_style')) $layout = gardener_set($_GET, 'layout_style'); else
	$layout = gardener_set( $meta, 'layout', 'full' );
	$sidebar = gardener_set( $meta, 'sidebar', 'blog-sidebar' );
	$classes = ( !$layout || $layout == 'full' || gardener_set($_GET, 'layout_style')=='full' ) ? ' col-lg-12 col-md-12 col-sm-12 col-xs-12 ' : ' col-lg-9 col-md-12 col-sm-12 col-xs-12 ' ;
	$bg = gardener_set($meta1, 'header_img');
	$title = gardener_set($meta1, 'header_title');
	$link =  gardener_set($meta1, 'page_link');
?>
<!-- ============================= Inner Banner ========================== -->
<section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
            </div>
        </div>
    </div>
</section> <!-- /inner_banner -->
<!-- ============================= /Inner Banner ========================== -->

<!-- ============================ BreadCrumb ============================= -->
<div class="breadcrumb">
    <div class="container">
        <?php echo gardener_get_the_breadcrumb(); ?>
    </div>
</div> <!-- /breadcrumb -->
<!-- ============================ /BreadCrumb ============================= -->

<section class="blog_fullwidth container news">
    <div class="row">
        <!-- sidebar area -->
        <?php if( $layout == 'left' ): ?>
            <?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->
        
        <div class="single_blog_fullwidth <?php echo esc_attr($classes);?>">
			<?php while( have_posts() ): the_post();?>
                <!-- blog post item -->
                <?php the_content(); ?>
                <?php comments_template(); ?><!-- end comments -->
            <?php endwhile;?> 
            <!-- Pagination -->
            <?php gardener_the_pagination(); ?>
        </div>
        
        <!-- sidebar area -->
        <?php if( $layout == 'right' ): ?>
            <?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->

    </div> <!-- /row -->

</section> <!-- /blog_fullwidth -->

<!-- ====================== /Blog - Fullwidth With Sidebar ================== -->

<?php get_footer(); ?>