<?php
ob_start() ;?>
<!-- ===================== Welcome Banner ============== -->

<section class="welcome_banner container ">
    <div class="welcome_banner_bg" style="background-image:url('<?php echo wp_get_attachment_url($bg_img, 'full');?>')">
        <div class="overlay"><div class="overlay_border"></div></div>
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                <h4><?php echo balanceTags($title);?></h4>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <a href="<?php echo esc_url($btn_link);?>" class="transition3s"><?php echo balanceTags($btn_text);?></a>
            </div>
        </div> <!-- /row -->
    </div> <!-- /welcome_banner_bg -->
</section> <!-- /welcome_banner -->

<!-- ===================== /Welcome Banner ============== -->

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   