<?php  
   global $post ;
   $count = 0;
   $paged = get_query_var('paged');
   $query_args = array('post_type' => 'post' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order, 'paged'=>$paged);
   if( $cat ) $query_args['category_name'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ================================= News ============================== -->
<section class="news <?php if($no_pad == true) echo 'no-pad';?>">
    <div class="container">
        <?php if($title || $btn_text):?>
        <div class="row">
            <div class="col-lg-6 col-md-7 col-sm-9 col-xs-12">
                <div class="title_holder2">
                    <h3><?php echo balanceTags($title);?></h3>
                </div> <!-- /title_holder2 -->
            </div>
            <div class="col-lg-6 col-md-5 col-sm-3 col-xs-12 more_news">
                <a class="main_anchor transition-ease" href="<?php echo esc_url($btn_link);?>"><?php echo balanceTags($btn_text);?><i class="fa fa-caret-right"></i></a>
            </div>
        </div> <!-- /row -->
        <?php endif;?>
        <div class="row">
            
            <?php while($query->have_posts()): $query->the_post();
                global $post ; 
                $post_meta = _WSH()->get_meta();
            ?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 single_blog_post">
                <div class="img_holder">
                    <?php the_post_thumbnail('gardener_four', array('class' => 'img-responsive'));?>
                    <div class="overlay transition3s">
                        <div class="icon_position_table">
                            <div class="icon_container border_round">
                                <a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="border_round"><i class="fa fa-chain"></i></a>
                            </div>
                        </div>
                    </div>
                </div> <!-- /img_holder -->
                <div class="post">
                    <h5><?php the_title();?></h5>
                    <ul>
                        <li><a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>" class="transition-ease"><?php echo get_the_date('M d, Y');?></a></li>
                        <li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>" class="transition-ease"><?php esc_html_e('By :', 'gardener');?> <?php the_author();?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_the_id()).'#comments');?>" class="transition-ease"><?php comments_number( '0 comment', '1 comment', '% comments' ); ?></a></li>
                    </ul>
                    <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                </div> <!-- /post -->
            </div> <!-- /single_blog_post -->
            <?php endwhile;?>
		</div> <!-- /row -->
		<?php if(!$hide_pagination):?>
        <div class="clearfix" style="text-align:center;">
        	<?php gardener_the_pagination(array('total'=>$query->max_num_pages, 'next_text' => '<i class="fa fa-angle-double-right"></i>', 'prev_text' => '<i class="fa fa-angle-double-left"></i>')); ?>
    	</div>
		<?php endif;?>
        
    </div>
</section> <!-- /news -->

<!-- =============================== /News ========================== -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>