<?php   
ob_start();
?>
<!-- ======================== google map ====================== -->
    <div class="map">
        <div class="google-map" id="contact-google-map" style="height:535px; width:100%;"></div>
    </div>
<!-- ======================= /google map ========================= -->

<script type="text/javascript">

// Google map 
jQuery(document).on('ready', function() {
  
  var settingsItemsMap = {
        zoom: 12,
        center: new google.maps.LatLng(<?php echo balanceTags($map_lat);?>, <?php echo balanceTags($map_long);?>),
        zoomControlOptions: {
          style: google.maps.ZoomControlStyle.LARGE
        },
        scrollwheel: false,
        styles:[
            { featureType: "water", stylers: [ { color: "#c0d887"} ] },
            { featureType: "road", stylers: [ { color: "#f2f2f2" } ] }
        ],
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById('contact-google-map'), settingsItemsMap );
    var image = '<?php echo get_template_directory_uri();?>/images/home/map-icon.png';
    var myMarker = new google.maps.Marker({
        position: new google.maps.LatLng(<?php echo balanceTags($mark_lat);?>, <?php echo balanceTags($mark_long);?>),
        draggable: true,
        icon: image
    });

    map.setCenter(myMarker.position);
    myMarker.setMap(map);
    // Google map 

});
	
</script>
<?php return ob_get_clean();?>		