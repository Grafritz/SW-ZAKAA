<?php
ob_start() ;?>
<!-- ======================== Buy on Themeforest =======================  -->
<section class="buy_on_themeforest" style="background-image:url('<?php echo wp_get_attachment_url($bg_img, 'full');?>')">
    <div class="container">
        <h4><?php echo balanceTags($title);?></h4>
        <a href="<?php echo balanceTags($btn_link);?>" class="button_main mouse_hover2 transition3s"><?php echo balanceTags($btn_text);?></a>
    </div>
</section> <!-- /buy_on_themeforest -->

<!-- ======================== /Buy on Themeforest =======================  -->

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   