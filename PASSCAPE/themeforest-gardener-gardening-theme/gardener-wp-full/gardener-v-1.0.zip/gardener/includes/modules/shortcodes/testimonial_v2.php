<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_testimonials' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['testimonials_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ========================== Testimonials ========================= -->
<div class="client_testimonial">
<section class="testimonial">
    <div class="container">
        <div class="row">
            
            <?php while($query->have_posts()): $query->the_post();
					global $post ; 
					$client_meta = _WSH()->get_meta();
			?>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="client_speach">
                    <h5><?php the_title();?></h5>
                    <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                    <div class="client_name">
                        <h5><?php echo gardener_set($client_meta, 'designation');?></h5>
                        <ul>
                            <?php
                                $ratting = gardener_set($client_meta, 'testimonial_rating');
                                for ($x = 1; $x <= 5; $x++) {
                                    if($x <= $ratting) echo '<li><a href="#"><i class="fa fa-star"></i></a></li>'; else echo '<li><a href="#"><i class="fa fa-star empty"></i></a></li>'; 
                                }
                            ?>
                        </ul>
                    </div> <!-- /client_name -->
                    <img src="<?php echo gardener_set($client_meta, 'sign_img');?>" alt="<?php esc_html_e('sign', 'gardener');?>">
                </div>
                 <!-- /client_speach -->
            </div>
            <?php if(($count%2) == 0 && $count != 0):?>
			</div><div class="row">
		<?php endif; ?>
            <?php $count++; endwhile;?>       
        </div>
            
    </div> <!-- /container -->
</section> <!-- /testimonial -->
</div>

<!-- ========================== /Testimonials ========================= -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>