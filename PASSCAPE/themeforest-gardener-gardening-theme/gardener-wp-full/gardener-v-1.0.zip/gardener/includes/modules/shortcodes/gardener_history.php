<?php ob_start(); ?>
<!-- ============================ Award achievement ========================== -->

<section class="award_achievement container">
    <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 text pull-right">
            <div class="title_holder2">
                <h3 style="margin-top:0; line-height:50px;"><?php echo balanceTags($title);?></h3>
            </div> <!-- /title_holder2 -->
            <p><?php echo balanceTags($text);?></p>
            <div class="row award_counter">
                <?php echo do_shortcode( $contents );?>
            </div>
        </div>

        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 img_bg pull-left" style="background-image:url('<?php echo wp_get_attachment_url($bg_img, 'full');?>')">
            <img src="<?php echo wp_get_attachment_url($img, 'full');?>" alt="<?php esc_html_e('images', 'gardener')?>" class="img-responsive">
        </div>
        
    </div> <!-- /row -->
</section> <!-- /award_achievement -->

<!-- ============================ /Award achievement ========================== -->

<?php return ob_get_clean(); ?>