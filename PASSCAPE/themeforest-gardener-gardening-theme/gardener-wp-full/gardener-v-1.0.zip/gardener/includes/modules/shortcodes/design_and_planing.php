<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   $data_filtration = array();
   $data_content = array();
   ?>
   
<?php if($query->have_posts()):  ?>
<?php while($query->have_posts()): $query->the_post();
	  global $post ; 
	  $services_meta = _WSH()->get_meta();
	  $active = ($count == 1) ? 'class="active"' : '';
	  $active_in = ($count == 1) ? ' in active ' : '';
	  
	  $data_filtration[get_the_id()] = '<li '.$active.'><a href="#garden'.get_the_id().'" data-toggle="tab">'.get_the_title($post->ID).'</a></li>';
	  $data_content[get_the_id()] = '<div class="tab-pane '.$active_in.' fade row" id="garden'.get_the_id().'">
										'.$post->post_content.'
									</div>';
?>
<?php $count++; endwhile; endif;
wp_reset_postdata();
ob_start() ;
?>  

<!-- =================== services page content ================== -->
<section class="service_page_content">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                <div class="tab_nav_holder">
                <!-- Nav tabs -->
                    <ul class="nav nav-tabs tabs-left"><!-- 'tabs-right' for right tabs -->
						<?php if($see_all_link):?>
							<li><a href="<?php echo esc_url($see_all_link);?>"><?php esc_html_e('See All Services', 'gardener');?></a></li>
						<?php endif;?>
						<?php foreach($data_filtration as $key => $value):?>
							<?php echo balanceTags($value);?>
						<?php endforeach;?>
                    </ul>
                </div>
                <div class="pull-left brochures">
					<?php echo balanceTags($contents);?>
                    <div class="img_holder">
                        <img src="<?php echo wp_get_attachment_url($left_img, 'full');?>" alt="<?php esc_html_e('image', 'gardener');?>">
                        <div class="overlay">
                            <div class="border">
                                <span class="border_round"><i class="fa fa-phone"></i></span>
                                <h6><?php echo balanceTags($left_title);?></h6>
                                <a href="tel:<?php echo esc_attr($left_phone);?>"><?php echo balanceTags($left_phone);?></a>
                            </div> <!-- /border -->
                        </div> <!-- /overlay -->
                    </div> <!-- /img_holder -->
                </div>
            </div>
            <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">
                <div class="tab_details">
                 <!-- Tab panes -->
                    <div class="tab-content">
                       <?php foreach($data_content as $key => $content):?>
                            <?php echo balanceTags($content);?>
                       <?php endforeach;?> 
                    </div>
                </div> <!-- End tab_details -->
            </div>
        </div> <!-- End row -->
        
    </div> <!-- End container -->
</section> <!-- /service_page_content -->

<!-- =================== /services page content ================== -->

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>