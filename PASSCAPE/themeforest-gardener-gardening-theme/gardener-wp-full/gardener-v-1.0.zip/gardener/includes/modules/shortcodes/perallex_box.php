<?php
ob_start() ;?>
<!-- =============================== Parallax ======================== -->
<section class="parallax" style="background-image:url('<?php echo wp_get_attachment_url($bg_img, 'full');?>')">
    <div class="overlay"></div>
    <div class="container parallex_text">
        <h3><?php echo balanceTags($title);?></h3>
        <p><?php echo balanceTags($text);?></p>
        <h5><?php echo balanceTags($sub_title);?> <a href="<?php echo esc_url($btn_link);?>"><?php echo balanceTags($btn_text);?></a></h5>
    </div> <!-- /container -->
</section> <!-- /Parallax -->

<!-- =============================== /Parallax ======================== -->

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   