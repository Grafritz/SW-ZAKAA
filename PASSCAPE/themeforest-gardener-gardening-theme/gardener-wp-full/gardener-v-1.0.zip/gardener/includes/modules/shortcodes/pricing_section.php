<?php ob_start(); ?>
<!-- =========================== Pricing table ============================ -->
<section class="pricing_table">
    <div class="container">
        <div class="title_holder2" style="text-align:center;">
            <h3 style="margin-top: -6px;"><?php echo balanceTags($title);?> <span><?php echo balanceTags($title2);?></span></h3>
        </div> <!-- /title_holder2 -->
        <div class="row">
            <?php echo do_shortcode( $contents );?>	
        </div> <!-- /row -->
    </div> <!-- /container -->
</section> <!-- /pricing_table -->

<!-- =========================== /Pricing table ============================ -->

<?php return ob_get_clean(); ?>