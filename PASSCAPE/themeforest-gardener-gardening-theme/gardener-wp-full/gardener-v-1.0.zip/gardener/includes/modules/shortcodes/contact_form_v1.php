<?php
   ob_start();
?>

<div class="project_started submit_form">
    <div class="title_holder2">
        <h3><?php echo balanceTags($title);?></h3>
    </div> <!-- /title_holder2 -->
    <div class="row">
		<?php echo do_shortcode(bunch_base_decode($contact_form));?>
    </div>
</div> <!-- /project_started -->

<?php return ob_get_clean();?>		