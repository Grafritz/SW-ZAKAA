<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_faqs' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   if( $cat ) $query_args['faqs_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>

    <div class="title_holder2">
        <h3 style="margin-top:15px;"><?php echo balanceTags($title);?> <span><?php echo balanceTags($title2);?></span></h3>
    </div> <!-- /title_holder2 -->
    <div class="accordion_style_two">
        <div class="panel-group" id="accordion_two">
        
            <?php while($query->have_posts()): $query->the_post();
                global $post ; 
                $faqs_meta = _WSH()->get_meta();
            ?>
            <div class="panel">
                <div class="panel-heading">
                    <h6 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion_two" href="#collapse11<?php echo get_the_id();?>">
                        <?php the_title();?></a>
                    </h6>
                </div>
                <div id="collapse11<?php echo get_the_id();?>" class="panel-collapse collapse">
                    <div class="panel-body">
                        <?php the_content();?>
                    </div>
                </div>
            </div> <!-- /panel 1 -->
            <?php endwhile;?>
        </div> <!-- end #accordion_two -->
    </div>

<!-- ============================ /faq page content ========================= -->

<?php endif; ?>

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>