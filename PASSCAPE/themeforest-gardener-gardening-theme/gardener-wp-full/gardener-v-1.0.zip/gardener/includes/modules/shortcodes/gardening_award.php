<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_testimonials' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['testimonials_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<?php while($query->have_posts()): $query->the_post();
	  global $post ; 
	  $testimonial_meta = _WSH()->get_meta();
	  $active_filter = ($count == 1) ? 'active' : '';
	  $active_tab = ($count == 1) ? 'active' : '';
	  $data = get_the_content();
	 
	  $data_filtration[get_the_id()] = '<li data-target="#award-slider '.get_the_id().'" data-slide-to="0" class="'.$active_filter.'"></li>';
	  									
	  $data_content[get_the_id()] = '<div class="item '.$active_tab.'">
									  '.get_the_post_thumbnail($post->ID).'
									  <h5>'.get_the_title($post->ID).'</h5>
									  '.get_the_content($post->ID).'
									</div>';
									
?> 
<?php $count++; endwhile; endif;
wp_reset_postdata();
ob_start() ;
?> 
<div class="award_winning">
    <div class="img_holder flt_right">
        <img src="<?php echo wp_get_attachment_url($bg_img, 'full');?>" alt="<?php esc_html_e('images', 'gardener');?>">
    </div> <!-- /img_holder -->
    <div class="text">
        <div class="title_holder2">
            <h3><?php echo balanceTags($title);?></h3>
        </div> <!-- /title_holder2 -->
        <div class="slider_container">
            <div id="award-slider" class="carousel slide" data-ride="carousel">
              <!-- Indicators -->
              <ol class="carousel-indicators">
                <?php foreach($data_filtration as $key => $value):?>
					<?php echo balanceTags($value);?>
                <?php endforeach;?>
              </ol>
              <!-- Wrapper for slides -->
              <div class="carousel-inner inner_slider_container" role="listbox">
                <?php foreach($data_content as $key => $content):?>
					<?php echo balanceTags($content);?>
				<?php endforeach;?>
              </div> <!-- end inner_slider_container -->
            </div> <!-- end #award-slider -->
        </div> <!-- end slider_container -->
    </div>
</div>

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>