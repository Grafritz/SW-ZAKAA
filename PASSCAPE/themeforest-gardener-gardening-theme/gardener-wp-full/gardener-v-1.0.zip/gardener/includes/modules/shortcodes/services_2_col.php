<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ===================== Welcome intro ============= -->
<section class="welocme_intro">
    <div class="container">
        <div class="row">
            <?php while($query->have_posts()): $query->the_post();
					global $post ; 
					$services_meta = _WSH()->get_meta();
			?>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 irrigation">
                <div class="img_holder">
                    <?php the_post_thumbnail('gardener_two', array('class' => 'img-responsive1'));?>
                </div>
                <div class="info">
                    <h5><?php the_title();?></h5>
                    <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                    <a class="read_more main_anchor transition-ease" href="<?php echo gardener_set($services_meta, 'readmore_link');?>"><?php esc_html_e('Read More', 'gardener');?> <i class="fa fa-caret-right"></i></a>
                </div>
            </div>
            <?php endwhile;?>
        </div> <!-- /row -->
    </div> <!-- /container -->
</section> <!-- /welocme_intro -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>