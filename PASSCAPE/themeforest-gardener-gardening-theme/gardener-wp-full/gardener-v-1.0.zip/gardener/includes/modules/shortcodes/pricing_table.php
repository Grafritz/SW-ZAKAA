<?php ob_start(); ?>

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="price_box hvr-float-shadow transition5s">
        <div class="rate">
            <p><span><?php echo balanceTags($currency);?></span> <?php echo balanceTags($price);?></p>
        </div> <!-- /rate -->
        <h5><?php echo balanceTags($title);?></h5>
        <span><?php echo balanceTags($plan);?></span>
        <ul>
            <?php $fearures = explode("\n",$feature_str);?>

				<?php foreach($fearures as $feature):?>
                <li><?php echo balanceTags($feature);?></li>
                <?php endforeach;?>
        </ul>
        <a href="<?php echo esc_url($btn_link);?>" class="mouse_hover3 transition3s"><?php echo balanceTags($btn_text);?></a>
    </div> <!-- /price_box -->
</div>

<?php return ob_get_clean(); 