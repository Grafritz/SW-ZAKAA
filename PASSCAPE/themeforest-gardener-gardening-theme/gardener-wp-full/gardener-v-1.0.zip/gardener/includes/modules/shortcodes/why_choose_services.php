<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ========================= Why Choosing Gardener ================= -->
<section class="choosing_gardener">
    <div class="container">
        <div class="row">
            <div class="title_holder2" style="text-align:center; padding-right: 21px; padding-bottom: 44px;">
                <h3><?php echo balanceTags($title);?> <span><?php echo balanceTags($title2);?></span></h3>
            </div> <!-- /title_holder2 -->
        </div> <!-- /row -->
        <div class="row">
            
            <?php while($query->have_posts()): $query->the_post();
                    global $post ; 
                    $services_meta = _WSH()->get_meta();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="choosing_reason transition3s">
                    <div class="icon_holder border_round">
                        <i class="<?php echo gardener_set($services_meta, 'fontawesome');?> border_round"></i>
                    </div> <!-- /icon_holder -->
                    <div class="text">
                        <h5><?php the_title();?></h5>
                        <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                    </div> <!-- /text -->
                </div> <!-- /choosing_reason -->
            </div>
            <?php endwhile;?>
        </div> <!-- /row -->

    </div> <!-- /container -->
</section>	<!-- /choosing_gardener -->
<!-- ========================= /Why Choosing Gardener ================= -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>