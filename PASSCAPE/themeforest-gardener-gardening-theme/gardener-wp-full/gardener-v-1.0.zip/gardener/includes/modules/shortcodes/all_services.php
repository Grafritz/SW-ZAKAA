<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- =========================== All services page ======================== -->
<div class="all_services">
<section class="service_page container">
    <div class="row">
        
        <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$services_meta = _WSH()->get_meta();
		?>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="service_item">
                <div class="img_holder">
                    <a href="design-and-planning.html">
                        <?php the_post_thumbnail('gardener_six', array('class' => 'img-responsive'));?>
                        <div class="overlay transition3s">
                            <div class="border"></div>
                        </div> <!-- /overlay -->
                    </a>
                </div> <!-- /img_holder -->
                <div class="text">
                    <h5><?php the_title();?></h5>
                    <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                    <a href="<?php echo gardener_set($services_meta, 'ext_url');?>" class="main_anchor transition-ease"><?php esc_html_e('Read More', 'gardener');?> <i class="fa fa-caret-right"></i></a>
                </div> <!-- /text -->
            </div> <!-- /service_item -->
        </div>
        <?php endwhile;?>
    </div>
</section> <!-- /service_page -->
</div>
<!-- =========================== /All services page ======================== -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>