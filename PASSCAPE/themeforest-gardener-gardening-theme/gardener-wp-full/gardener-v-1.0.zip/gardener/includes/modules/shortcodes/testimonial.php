<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_testimonials' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['testimonials_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ========================== Testimonials ========================= -->
<section class="testimonial <?php if($grey_theme == true) echo 'grey_theme';?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12">
                <div class="title_holder2">
                    <h3><span><?php echo balanceTags($title);?></span> <?php echo balanceTags($title2);?></h3>
                </div> <!-- /title_holder2 -->
            </div>
            <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12">
                <h6><?php echo balanceTags($text);?></h6>
            </div>
        </div> <!-- /row -->

        <div class="owl_slider row">
                <div id="owl-demo">
                    
                    <?php while($query->have_posts()): $query->the_post();
							global $post ; 
							$client_meta = _WSH()->get_meta();
					?>
                    <div class="item">
                        <div class="client_speach">
                            <h5><?php the_title();?></h5>
                            <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                            <div class="client_name">
                                <h5><?php echo gardener_set($client_meta, 'designation');?></h5>
                                <ul>
                                	<?php
										$ratting = gardener_set($client_meta, 'testimonial_rating');
										for ($x = 1; $x <= 5; $x++) {
											if($x <= $ratting) echo '<li><a href="#"><i class="fa fa-star"></i></a></li>'; else echo '<li><a href="#"><i class="fa fa-star empty"></i></a></li>'; 
										}
									?>
                                </ul>
                            </div> <!-- /client_name -->
                            <img src="<?php echo gardener_set($client_meta, 'sign_img');?>" alt="<?php esc_html_e('sign', 'gardener');?>">
                        </div> <!-- /client_speach -->
                    </div>
                   <?php endwhile;?> 
                </div> <!-- end #owl-demo -->
                <div class="customNavigation">
                  <a class="prev"><i class="fa fa-chevron-left"></i></a>
                  <a class="next"><i class="fa fa-chevron-right"></i></a>
                </div>
            </div> <!-- End owl-slider -->
    </div> <!-- /container -->
</section> <!-- /testimonial -->

<!-- ========================== /Testimonials ========================= -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>