<?php ob_start(); ?>

<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
    <?php if($counter_plus):?>
		<span class="counter"><?php echo balanceTags($number);?></span><span>+</span>
	<?php else:?>
		<span class="counter"><?php echo balanceTags($number);?></span>
	<?php endif;?>
	<p><?php echo balanceTags($text);?></p>
</div>

<?php return ob_get_clean(); 