<?php
ob_start() ;?>

<!-- =============================== Contact us ========================== -->
<section class="contact_us">
    <div class="container">
        <div class="row heading">
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="title_holder2">
                    <h3><?php echo balanceTags($title);?> <span><?php echo balanceTags($title2);?></span></h3>
                </div> <!-- /title_holder2 -->
            </div>
            <div class="col-lg-9 col-md-8 col-sm-6 col-xs-12">
                <p><?php echo balanceTags($text);?></p>
            </div>
        </div> <!-- /row -->
        <div class="row contact_deatils">
            <div class="col-lg-8 col-md-7 col-sm-6 col-xs-12 pull-right submit_form">
                <?php echo do_shortcode(bunch_base_decode($get_in_form));?>
            </div>
            <div class="col-lg-4 col-md-5 col-sm-6 col-xs-12 pull-left address">
                <h4 style="line-height:45px;"><?php echo balanceTags($sub_title);?></h4>
                <div class="address_holder">
                    <div class="address_type">
                        <div class="icon_holder border_round">
                            <div class="icon_bg border_round">
                                <i class="fa fa-map-marker"></i>
                            </div> <!-- /icon_bg -->
                        </div> <!-- /icon_holder -->
                        <div class="text">
                            <h5><?php esc_html_e('Address', 'gardener');?></h5>
                            <p><?php echo balanceTags($address);?></p>
                        </div> <!-- /text -->
                    </div> <!-- /address_type -->

                    <div class="address_type">
                        <div class="icon_holder border_round">
                            <div class="icon_bg border_round">
                                <i class="fa fa-phone"></i>
                            </div> <!-- /icon_bg -->
                        </div> <!-- /icon_holder -->
                        <div class="text">
                            <h5><?php esc_html_e('Contact Details', 'gardener');?></h5>
                            <p><?php echo balanceTags($phone);?></p>
                            <a href="<?php echo esc_url($email_link);?>"><?php echo balanceTags($address);?></a>
                        </div> <!-- /text -->
                    </div> <!-- /address_type -->

                    <div class="address_type">
                        <div class="icon_holder border_round">
                            <div class="icon_bg border_round">
                                <i class="fa fa-clock-o"></i>
                            </div> <!-- /icon_bg -->
                        </div> <!-- /icon_holder -->
                        <div class="text">
                            <h5><?php echo balanceTags($houre);?></h5>
                            <ul style="margin-top: 14px;">
                                <?php $fearures = explode("\n",$feature_str);?>
								<?php foreach($fearures as $feature):?>
            						<li><?php echo balanceTags($feature);?></li>
            					<?php endforeach;?>
                            </ul>
                        </div> <!-- /text -->
                    </div> <!-- /address_type -->

                </div> <!-- /address_holder -->
            </div>
        </div> <!-- /contact_deatils -->
    </div> <!-- /container -->
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   