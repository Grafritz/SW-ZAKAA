<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_faqs' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['faqs_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ============================ faq page content ========================= -->
<div class="faq">
<section class="faq_style_one container">
    <div class="row">
        <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$faqs_meta = _WSH()->get_meta();
		?>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><?php the_title();?><span><?php esc_html_e('q', 'gardener');?></span></h5>
            <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
        </div>
        <?php if(($count%2) == 0 && $count != 0):?>
            </div><div class="row">
        <?php endif; ?>
        <?php $count++; endwhile;?>
    </div>
    
</section> <!-- /faq_style_one -->
</div>
<!-- =============== -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>