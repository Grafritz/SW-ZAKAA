<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   

<!-- ===================== Welcome section ============= -->
<section class="welcome_sec">
    <div class="container welcome_data_container">
        <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 welcome_title">
                    <div class="title_holder">
                        <h2><?php echo balanceTags($title);?></h2>
                    </div> <!-- /title_holder -->
                    <div class="text">
                        <p><?php echo balanceTags($contents);?></p>
                        <a class="view_services main_anchor transition-ease" href="<?php echo esc_url($btn_link);?>"><?php echo balanceTags($btn_text);?> <i class="fa fa-caret-right"></i></a>
                    </div> <!-- /text -->
                </div> <!-- /welcome_title -->
                
                <?php while($query->have_posts()): $query->the_post();
						global $post ; 
						$services_meta = _WSH()->get_meta();
				?>
                <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 design_planting">
                    <div class="img_holder">
                        <?php the_post_thumbnail('gardener_one', array('class' => 'img-responsive'));?>
                        <div class="overlay transition3s">
                            <div class="overlay_border"></div>
                        </div>
                    </div> <!-- /img_holder -->
                    <div class="text">
                        <h5><?php the_title();?></h5>
                        <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                        <a class="read_more main_anchor transition-ease" href="<?php echo gardener_set($services_meta, 'readmore_link');?>"><?php esc_html_e('Read More', 'gardener');?> <i class="fa fa-caret-right"></i></a>
                    </div>
                </div> <!-- /design_planting -->
                <?php endwhile;?>
        </div> <!-- /row -->
    </div> <!-- /welcome_data_container -->
</section> <!-- /welcome_sec -->
<!-- ===================== /Welcome section ============= -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>