<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- =============================== Gardener history ========================= -->
<section class="gardner_history container">
    <div class="row">
        
        <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$services_meta = _WSH()->get_meta();
		?>
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 history_part">
            <div class="year flt_left">
                <span>
                    <?php echo gardener_set($services_meta, 'year');?>
                </span>
            </div> <!-- /year -->
            <div class="title flt_right">
                <h5 style="line-height:36px;"><?php the_title();?></h5>
            </div> <!-- /title -->
            <div class="clear_fix"></div>
            <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
        </div>
        <?php endwhile;?>
    </div> <!-- /row -->
</section> <!-- /gardner_history -->

<!-- =============================== /Gardener history ========================= -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>