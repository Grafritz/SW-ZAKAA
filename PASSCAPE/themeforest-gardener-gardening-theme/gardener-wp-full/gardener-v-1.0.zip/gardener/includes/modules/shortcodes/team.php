<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_team' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['team_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!-- ========================== Team Landscapers ========================== -->
<section class="team_landscape">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="title_holder2">
                    <h3><?php echo balanceTags($title);?> <span><?php echo balanceTags($title2);?></span></h3>
                </div> <!-- /title_holder2 -->
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 more_news">
                <a class="main_anchor transition-ease" href="<?php echo esc_url($btn_link);?>"><?php echo balanceTags($btn_text);?><i class="fa fa-caret-right"></i></a>
            </div>
        </div> <!-- /row -->
        <div class="row" style="margin-top:43px;">
            
            <?php while($query->have_posts()): $query->the_post();
					global $post ; 
					$team_meta = _WSH()->get_meta();
			?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="team_member">
                    <div class="img_holder">
                        <?php the_post_thumbnail('gardener_five', array('class' => 'img-responsive'));?>
                        
                        <div class="overlay transition3s">
                        	<?php if($socials = gardener_set($team_meta, 'bunch_team_social')):?>
                            <div class="border">
                                <?php foreach($socials as $key => $value):?>
                                <div class="icon_holder border_round">
                                    <a href="<?php echo esc_url(gardener_set($value, 'social_link'));?>" class="border_round"><i class="fa <?php echo gardener_set($value, 'social_icon');?>"></i></a>
                                </div>
                                <?php endforeach;?>
                            </div>
                            <?php endif;?>
                        </div> <!-- /overlay -->
                        
                    </div> <!-- /img_holder -->
                    <div class="text">
                        <h5><?php the_title();?></h5>
                        <span><?php echo gardener_set($team_meta, 'designation');?></span>
                        <p><?php echo gardener_trim(get_the_excerpt(), $text_limit);?></p>
                        <a href="<?php echo gardener_set($team_meta, 'email_link');?>" class="transition-ease"><i class="fa fa-envelope-o"></i> <span><?php esc_html_e('Email:', 'gardener');?></span> <?php echo gardener_set($team_meta, 'email');?></a>
                    </div> <!-- /text -->
                </div> <!-- /team_member -->
            </div>
            <?php endwhile;?>
            
        </div> <!-- /row -->
    </div>
</section> <!-- /team_landscape -->

<!-- ========================== /Team Landscapers ========================== -->

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>