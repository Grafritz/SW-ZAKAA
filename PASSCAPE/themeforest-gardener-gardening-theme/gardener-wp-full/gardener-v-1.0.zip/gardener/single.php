<?php $options = _WSH()->option();
	get_header(); 
	$settings  = gardener_set(gardener_set(get_post_meta(get_the_ID(), 'bunch_page_meta', true) , 'bunch_page_options') , 0);
	$meta = _WSH()->get_meta('_bunch_layout_settings');
	$meta1 = _WSH()->get_meta('_bunch_header_settings');
	$meta2 = _WSH()->get_meta();
	_WSH()->page_settings = $meta;
	if(gardener_set($_GET, 'layout_style')) $layout = gardener_set($_GET, 'layout_style'); else
	$layout = gardener_set( $meta, 'layout', 'full' );
	if( !$layout || $layout == 'full' || gardener_set($_GET, 'layout_style')=='full' ) $sidebar = ''; else
	$sidebar = gardener_set( $meta, 'sidebar', 'blog-sidebar' );
	$classes = ( !$layout || $layout == 'full' || gardener_set($_GET, 'layout_style')=='full' ) ? ' col-lg-12 col-md-12 col-sm-12 col-xs-12 ' : ' col-lg-9 col-md-12 col-sm-12 col-xs-12 ' ;
	/** Update the post views counter */
	_WSH()->post_views( true );
	$bg = gardener_set($meta1, 'header_img');
	$title = gardener_set($meta1, 'header_title');
	$link =  gardener_set($meta1, 'page_link');
?>

<!-- ============================= Inner Banner ========================== -->
<section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
            </div>
        </div>
    </div>
</section> <!-- /inner_banner -->
<!-- ============================= /Inner Banner ========================== -->

<!-- ============================ BreadCrumb ============================= -->
<div class="breadcrumb">
    <div class="container">
        <?php echo gardener_get_the_breadcrumb(); ?>
    </div>
</div> <!-- /breadcrumb -->
<!-- ============================ /BreadCrumb ============================= -->

<!-- ====================== Blog - Fullwidth With Sidebar ================== -->

<section class="blog_fullwidth container news">
    <div class="row">
        
        <!-- sidebar area -->
		<?php if( $layout == 'left' ): ?>
			<?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->
        
        <div class="<?php echo esc_attr($classes);?> single_blog_fullwidth">
		<?php while( have_posts() ): the_post(); 
                $post_meta = _WSH()->get_meta();
            ?>
            <div class="single_blog_post">
                <?php if(has_post_thumbnail()):?>
				<div class="img_holder">
                        <?php the_post_thumbnail('gardener_eleven', array('class' => 'img-responsive'));?>
                        <div class="overlay transition3s">
                            <div class="icon_position_table">
                                <div class="icon_container border_round">
                                    <a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="border_round"><i class="fa fa-chain"></i></a>
                                </div>
                            </div>
                        </div>
                </div> <!-- /img_holder -->
				<?php endif;?>
                <div class="post g_post">
                    <h4><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php the_title();?></a></h4>
                    <ul class="g_list">
                        <li><a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>" class="transition-ease"><span><?php esc_html_e('Date :', 'gardener');?></span><?php echo get_the_date('M d, Y');?></a></li>
                        <li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>" class="transition-ease"><span><?php esc_html_e('By :', 'gardener');?></span> <?php the_author();?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_the_id()).'#comments');?>" class="transition-ease"><span><?php esc_html_e('Comment :', 'gardener');?></span><?php comments_number( '0 comment', '1 comment', '% comments' ); ?></a></li>
                        <li><a><span><?php esc_html_e('Category :', 'gardener');?></span></a><?php the_category(', '); ?></li>
                    </ul>
                    <?php the_content();?>
                </div> <!-- /post -->
            </div> <!-- /single_blog_post -->

            <div class="share_item">
                <h5><?php esc_html_e('Did You Like This Post? Share it :', 'gardener');?></h5>
                <div class="social_button">
				  <ul class="psocial shares clearfix">
					  <li class="facebook"><span class='st_facebook_large hovicon effect-1 sub-a'></span></li>
					  <li class="twitter"><span class="st_twitter_large hovicon effect-1 sub-a"></span></li>
					  <li class="google"><span class="st_googleplus_large hovicon effect-1 sub-a"></span></li>
					  <li class="pinterest"><span class='st_pinterest_large hovicon effect-1 sub-a'></span></li>
					  
				  </ul>
				  <script type="text/javascript">var switchTo5x=true;</script>
				  <script type="text/javascript" src="https://ws.sharethis.com/button/buttons.js"></script>
				  <script type="text/javascript">stLight.options({publisher: "e5f231e9-4404-49b7-bc55-0e8351a047cc", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
				  <br/>
				</div>
            </div> <!-- /share_item -->

            <!-- comment area -->
			<?php wp_link_pages(array('before'=>'<div class="paginate-links">'.esc_html__('Pages: ', 'gardener'), 'after' => '</div>', 'link_before'=>'<span>', 'link_after'=>'</span>')); ?>
            <?php comments_template(); ?><!-- end comments -->
		
		<?php endwhile;?>
        </div>

        <!-- sidebar area -->
		<?php if( $layout == 'right' ): ?>
			<?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->
    
    </div> <!-- /row -->

</section> <!-- /blog_fullwidth -->

<!-- ====================== /Blog - Fullwidth With Sidebar ================== -->

<?php get_footer(); ?>