<form action="<?php echo esc_url(home_url('/')); ?>" method="get" class="input-group">
    <input type="text" name="s" class="form-control" placeholder="<?php esc_html_e('Search Keywords', 'gardener');?>">
        <span class="input-group-btn">
            <button type="button"><i class="fa fa-search"></i></button>
        </span>
</form>
