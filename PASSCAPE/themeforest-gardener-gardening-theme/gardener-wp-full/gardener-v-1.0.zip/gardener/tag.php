<?php bunch_global_variable();
	$options = _WSH()->option();
	get_header(); 
	$meta = _WSH()->get_term_meta( '_bunch_category_settings' );
	if(gardener_set($_GET, 'layout_style')) $layout = gardener_set($_GET, 'layout_style'); else
	$layout = gardener_set( $meta, 'layout', 'right' );
	$sidebar = gardener_set( $meta, 'sidebar', 'blog-sidebar' );
	$view = gardener_set( $meta, 'view', 'list' ) ? gardener_set( $meta, 'view', 'list' ) : 'list';
	_WSH()->page_settings = array('layout'=>$layout, 'sidebar'=>$sidebar);
	$classes = ( !$layout || $layout == 'full' || gardener_set($_GET, 'layout_style')=='full' ) ? ' col-lg-12 col-md-12 col-sm-12 col-xs-12 ' : ' col-lg-9 col-md-12 col-sm-12 col-xs-12 ' ;
	if($layout == 'both') $classes = ' col-lg-6 col-md-6 col-sm-6 col-xs-12 ';  
	$bg = gardener_set($meta, 'header_img');
	$title = gardener_set($meta, 'header_title');
	$link =  gardener_set($meta, 'page_link');
?>
<!-- ============================= Inner Banner ========================== -->
<section class="inner_banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h3><?php if($title) echo balanceTags($title); else wp_title('');?></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="text-align:right;">
                <a href="<?php echo esc_url($link);?>" class="button_main get_in_touch transition3s"><?php esc_html_e('Get in Touch', 'gardener');?></a>
            </div>
        </div>
    </div>
</section> <!-- /inner_banner -->
<!-- ============================= /Inner Banner ========================== -->

<!-- ============================ BreadCrumb ============================= -->
<div class="breadcrumb">
    <div class="container">
        <?php echo gardener_get_the_breadcrumb(); ?>
    </div>
</div> <!-- /breadcrumb -->
<!-- ============================ /BreadCrumb ============================= -->

<!-- ====================== Blog - Fullwidth With Sidebar ================== -->

<section class="blog_fullwidth container news">
    <div class="row">
        <!-- sidebar area -->
		<?php if( $layout == 'left' ): ?>
			<?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->
        
        <div class="<?php echo esc_attr($classes);?> single_blog_fullwidth">
            <?php while( have_posts() ): the_post();?>
                <!-- Post -->
                <div id="post-<?php the_ID(); ?>" <?php post_class();?>>
                    <?php get_template_part( 'blog' ); ?>
                </div><!-- End Post -->
            <?php endwhile;?> 
				<!-- Pagination -->
			<div style="text-align:center;">
                <?php gardener_the_pagination(); ?>
            </div>
        </div>
        
        <!-- sidebar area -->
		<?php if( $layout == 'right' ): ?>
        	<?php if ( is_active_sidebar( $sidebar ) ) { ?>
                <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 shop_aside blog_aside">        
                    <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            <?php } ?>
        <?php endif; ?>
        <!-- sidebar area -->

	</div> <!-- /row -->

</section> <!-- /blog_fullwidth -->

<!-- ====================== /Blog - Fullwidth With Sidebar ================== -->
<?php get_footer(); ?>