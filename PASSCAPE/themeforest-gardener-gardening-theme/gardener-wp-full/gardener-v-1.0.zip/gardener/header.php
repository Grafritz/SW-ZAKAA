<?php $options = _WSH()->option();
	bunch_global_variable();
	$icon_href = (gardener_set( $options, 'site_favicon' )) ? gardener_set( $options, 'site_favicon' ) : get_template_directory_uri().'/images/favicon.png';
 ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		 <!-- Basic -->
	    <meta charset="<?php bloginfo( 'charset' ); ?>">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<!-- Favcon -->
		<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ):?>
			<link rel="shortcut icon" type="image/png" href="<?php echo esc_url($icon_href);?>">
		<?php endif;?>
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
	<div class="body_container">
	<!-- ============================= Header ================================ -->
				<!-- ================ Top Header =================-->
	<?php if(gardener_set($options, 'topbar_settings')):?>
    <div class="top_header" id="top">
		<div class="container">
			<div class="row">
            	<?php if(gardener_set($options, 'welcome_text')):?>
				<div class="col-lg-7 col-md-8 col-sm-12 col-xs-12">
					<p><?php echo gardener_set($options, 'welcome_text')?></p>
				</div>
                <?php endif;?>
				<div class="col-lg-5 col-md-4 col-sm-12 col-xs-12 col-sm-12 col-xs-12">
					<ul>
						<li><a class="transition3s" href="<?php echo esc_url(gardener_set($options, 'carrers_link'));?>"><?php esc_html_e('Carrers', 'gardener');?></a></li>
						<li><a class="transition3s" href="<?php echo esc_url(gardener_set($options, 'purchase_link'));?>"><?php esc_html_e('Purchase Now', 'gardener');?></a></li>
						<?php if($languages_str = gardener_set($options, 'languages_str')):?>
						<li>
							<div class="dropdown">
							  <button class="btn-dropdown dropdown-toggle" type="button" id="dropdownMenu2001" data-toggle="dropdown" aria-haspopup="true">
							   	<span><?php esc_html_e('Language', 'gardener');?></span>
							  </button>
							  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2001">
							  	
								<?php $languages = explode("\n",$languages_str);?>
								
								<?php foreach($languages as $language):?>
                					<li><?php echo balanceTags($language);?></li>
                				<?php endforeach;?>
								
							  </ul>
							  
							</div>
						</li>
						<?php endif;?>
					</ul>
				</div>
			</div> <!-- /row -->
		</div> <!-- /container -->
	</div> <!-- /top_header -->
    <?php endif;?>

				<!-- ================ /Top Header =================-->

				<!-- ================ Bottom header ============= -->
	<div class="bottom_header <?php if ( !(has_nav_menu( 'main_menu' ) )) echo " logo_margin_bottom";?>">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-3 col-md-12 col-sm-12 col-xs-12">
					<div class="logo_holder">
						<?php if(gardener_set($options, 'logo_image')):?>
	                    	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="img-responsive" src="<?php echo esc_url(gardener_set($options, 'logo_image'));?>" alt="<?php esc_html_e('image', 'gardener');?>"></a>
						<?php else:?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri().'/images/logo/logo.png');?>" alt="<?php esc_html_e('image', 'gardener');?>"></a>
						<?php endif;?>
                    </div> <!-- /logo_holder -->
				</div>
				<?php if(gardener_set($options, 'address')):?>
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
					<div class="address">
						<?php echo gardener_set($options, 'address');?>
					</div><!--  /address -->
				</div>
                <?php endif;?>
                <?php if(gardener_set($options, 'schdule') || gardener_set($options, 'close')):?>
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
					<div class="time_schedule">
						<p><?php echo gardener_set($options, 'schdule');?></p>
						<span><?php echo gardener_set($options, 'close');?></span>
					</div><!--  /time_schedule -->
				</div>
                <?php endif;?>
				
                <?php if(gardener_set($options, 'show_shocial_icons')):?>
                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php if($socials = gardener_set(gardener_set($options, 'social_media'), 'social_media')): //gardener_printr($socials);?>
                    <div class="social_icon_header">
						<ul>
                        	<?php foreach($socials as $key => $value):
								if(gardener_set($value, 'tocopy')) continue;
							?>
                            <li class="transition3s border_round"><a href="<?php echo esc_url(gardener_set($value, 'social_link'));?>"><i class="fa <?php echo gardener_set($value, 'social_icon');?> border_round"></i></a></li>
							<?php endforeach;?>
                        </ul>
					</div><!--  /social_icon_header -->
                    <?php endif;?>
				</div>
                <?php endif;?>
			</div> <!-- /row -->
		</div> <!-- /container -->
	</div> <!-- /bottom_header -->
    
				<!-- ================ /Bottom header ============= -->

	<!-- ============================= /Header ============================== -->

	<!-- ================================ Menu ============================== -->
	<?php if ( has_nav_menu( 'main_menu' ) ):?>
	<div class="main_menu menu_fixed">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					
					<nav class="navbar navbar-default">
					   <!-- Collect the nav links, forms, and other content for toggling -->
					   <div class="collapse navbar-collapse flt_left" id="navbar-collapse-1">
					     <ul class="nav navbar-nav">
					     	<?php wp_nav_menu( array( 'theme_location' => 'main_menu', 'container_id' => 'navbar-collapse-1',
										'container_class'=>'navbar-collapse collapse navbar-right',
										'menu_class'=>'nav navbar-nav',
										'fallback_cb'=>false, 
										'items_wrap' => '%3$s', 
										'container'=>false,
										'walker'=> new Bunch_Bootstrap_walker()  
							) ); ?>
					     </ul>
					   </div><!-- /.navbar-collapse -->
					   <!-- Brand and toggle get grouped for better mobile display -->
					   <div class="navbar-header">
					     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
					       <span class="sr-only">Toggle navigation</span>
					       <span class="icon-bar"></span>
					       <span class="icon-bar"></span>
					       <span class="icon-bar"></span>
					     </button>
					   </div>
					   	<?php if(gardener_set($options, 'header_phone')):?>
                        	<p class="navbar-text flt_left"><a href="tel:+00419-306-2667" class="transition4s"><i class="fa fa-phone"></i><?php echo gardener_set($options, 'header_phone');?></a></p>
						<?php endif;?>
                    </nav> <!-- /navbar-default -->
					<?php endif;?>
				</div>
			</div> <!-- /row -->
		</div> <!-- /container -->
	</div> <!-- /main_menu -->
	<!-- ================================ /Menu ============================== -->